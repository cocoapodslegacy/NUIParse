//
//  NUIPShiftAction.h
//  NUIParse
//
//  Created by Tom Davie on 20/08/2012.
//  Copyright (c) 2012 In The Beginning... All rights reserved.
//

#import "NUIPShiftReduceAction.h"

@interface NUIPShiftAction : NUIPShiftReduceAction

@end
